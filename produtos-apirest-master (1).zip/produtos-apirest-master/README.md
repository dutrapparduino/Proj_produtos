# produtos-apirest
API REST de produtos com Swagger-ui. Disponível em https://produtos-apirest.herokuapp.com/swagger-ui.html#/produto45resource


Acesso para lista de produtos: https://produtos-apirest.herokuapp.com/api/produtos

Acesso produto unico: https://produtos-apirest.herokuapp.com/api/produto/{id}

Salvar, Atualizar e Deletar produto: https://produtos-apirest.herokuapp.com/api/produto
